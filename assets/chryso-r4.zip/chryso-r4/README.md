# Gold Transmutation Activity Cooldown

A check of one claim in a published paper, rebuilt and run by Ori.

## What this is

This folder rebuilds one calculation from [Adam Rutkowski, Jake Harter and Jason Parisi. Scalable Chrysopoeia via (n, 2n) Reactions Driven by Deuterium-Tritium Fusion Neutrons. arXiv:2507.13461v3 (2025)](https://arxiv.org/abs/2507.13461v3) and runs it.

**The claim checked (p. 17):** The radioactive decay model predicts that the activity concentration of the removed gold isotope mixture falls below 700 Ci/m^3 at approximately 6.8 years.

**How it is computed:** integrating these equations over time:

- `d(m_195)/dt = -(log(2) / t_half_195) * m_195`
- `d(m_196)/dt = -(log(2) / t_half_196) * m_196`
- `d(m_197)/dt = 0`
- `d(m_198)/dt = -(log(2) / t_half_198) * m_198`
- `d(m_199)/dt = -(log(2) / t_half_199) * m_199`

## The answer

| Claim | Paper | This run | Allowed difference | Result |
|---|---|---|---|---|
| cooldown time to Class A low level waste limit | 6.8 yr (p. 17) | 6.766 yr | ±0.136 yr (Ori proposed ±2% and the reviewer confirmed it; the paper printed no ±) | matches |
| cooldown time to Class 7 exempt limit | 13.7 yr (p. 17) | 13.76 yr | ±0.274 yr (Ori proposed ±2% and the reviewer confirmed it; the paper printed no ±) | matches |
| cooldown time to banana equivalent activity level | 17.7 yr (p. 17) | 17.55 yr | ±0.354 yr (Ori proposed ±2% and the reviewer confirmed it; the paper printed no ±) | matches |

## How sure Ori is

**Verified by this domain's own checks.**

A match with a printed number is agreement between two calculations, not a measurement.

## Run it yourself

Needs Python and nothing from Ori:

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python run.py
pytest
```

`python run.py` prints each claim beside the paper's number and writes `results/summary.json` and `results/series.csv`. `sim/model.py` is generated from the equations in the signed brief, so change an equation or an input by forking the run in Ori. The tolerances in `params.json` are yours: Ori carries them into its next run.

## Start with these

- `report.md`: Ori's write-up: what was asked, what ran, what came out.
- `figure.html`: The chart. Opens in any browser.
- `sim/model.py`: The calculation, as plain Python.
- `params.json`: Every number it reads, with its unit and where it came from.
- `targets.json`: The paper's numbers, the allowed difference, and Ori's verdict.
- `run.py`: Runs it without Ori; `tests/` checks it with `pytest`.

## Words used here

- **Brief**: the plan Ori wrote from the paper, which a person signed before anything ran.
- **Allowed difference (band)**: how far from the paper's number a result may land and still count as a match, fixed before the run.
- **Revision**: one run of this folder. Each is kept unchanged in `revisions/`.

## How to cite

- The paper: Adam Rutkowski, Jake Harter and Jason Parisi. Scalable Chrysopoeia via (n, 2n) Reactions Driven by Deuterium-Tritium Fusion Neutrons. arXiv:2507.13461v3 (2025), https://arxiv.org/abs/2507.13461v3.
- This check: Ori run `chryso-r4`, as recorded in this folder.

## This run

Signed by **Phil V** (revision 2).

Every parameter in the brief carries the page it was read from and the line exactly as printed there, and the brief names the document those pages belong to, so a reader can check any number against the source without Oriphim.

## Ori's record

The machine-readable record behind everything above: what was signed, what ran, every check, every model call. You do not need these to run or read the result.

- `brief.json`: The brief: the signed record the run executes. Every number carries where it came from. Before the run this is the brief; Oriphim shows it in the chat.
- `claims.json`: What the paper claims, each with the line it is printed on, and what Oriphim can do with each. The reach is computed by Oriphim, never by a model.
- `spec.json`: The executable specification the brief was bound to.
- `result.json`: Raw solver output.
- `environment.json`: Every installed Python package and version the run came out of: what to rebuild to re-run it.
- `output.json`: Quantities derived from the result.
- `data.json`: The numbers behind the figure.
- `scene.json`: The scene the figure was drawn from.
- `report.json`: The report as structured data.
- `analysis.json`: A model's reading of the results.
- `account.json`: What was simulated and what happened in it, in physical terms, built by the engine from the brief, the spec and the output, never by a model.
- `narrative.json`: What Ori said about the results, with every number in it checked against the record. The prose and the checks behind it.
- `narrative-brief.json`: What Ori said about the brief before the run, as shown in the chat.
- `narrative-writeup.json`: The record behind `report.md`: the write-up's text and the numbers it was checked against.
- `trace.json`: Every stage of the run, in order, with how long each took.
- `proposal-model-calls.json`: Every model call made while drafting the brief, verbatim.
- `preparation-model-calls.json`: Every model call made while preparing the run, verbatim.

## History

Every execution of this run, sealed in `revisions/` and never changed afterwards. The files above are the latest; these are all of them.

- **r1** · 2026-10-20 · Phil V · brief r2 · 5/5 checks pass · cooldown time to Class A low level waste limit 6.766 yr (pass) · cooldown time to Class 7 exempt limit 13.76 yr (pass) · cooldown time to banana equivalent activity level 17.55 yr (pass)

## The long hexadecimal strings

Several files carry a 64-character digest. None of them is an identifier to look up, and there is nothing to paste anywhere. Each is computed by Oriphim over its own output, so that a later disagreement can be settled by arithmetic rather than by memory.

- `brief_hash`: The brief exactly as signed. Any change to any value changes it.
- `output_hash`: The solver's raw output.
- `source_hash`: The version of Oriphim's own code that produced this run. Two runs sharing this value ran identical code.
- `code_hash`: The same digest, in `result.json`'s `identity` alongside the Oriphim version, commit, Python, platform and numerical-library versions the run came out of.
- `scene_sha256, data_sha256`: The exhibit. Renderer version plus these two fully determine the picture: re-render with the same three and you get the same image, or you have found a bug.
- `physics_hash`: The physical setup. The engine refuses to compare two runs whose values differ — that is what stops a comparison quietly mixing two different systems.

You are not expected to check these. They exist so that someone can.

## Reading this without Oriphim

`report.md` is plain Markdown with LaTeX in `$$` blocks: any Markdown viewer, or any model, can read it.
`figure.html` is self-contained and needs no server.
The JSON files are the record the engine works from; the Markdown is derived from them and is never read back.

## Checking Oriphim itself

The `*-model-calls.json` files are the receipts: every prompt sent to a model and every reply that came back, verbatim and in order. Nothing Oriphim did with a model is missing from them, and nothing in them was written by Oriphim after the fact. If you want to know whether a number in the brief was read from your paper or supplied by a model, those two files and the page anchors in `brief.json` settle it between them.

*Generated by Oriphim. Edits to this file are overwritten.*
