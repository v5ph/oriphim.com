"""Each number the paper reports, held to its band:  pytest

Runs the model once (run.simulate) and checks every target in targets.json,
printing this run's value beside the paper's. A target that needs Ori (a
difference between two study cases) is skipped, with why.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import run  # noqa: E402

TARGETS = run.load("targets.json")["targets"]


@pytest.fixture(scope="module")
def result() -> dict:
    return run.simulate()


@pytest.mark.parametrize("target", TARGETS, ids=[t["quantity"] for t in TARGETS])
def test_matches_the_paper_within_its_band(target: dict, result: dict) -> None:
    if target.get("needs_ori"):
        pytest.skip(target["needs_ori"])
    got = run.measure(target, result)
    assert got is not None, f"{target['quantity']}: this run produced no value"
    unit = f" {target['units']}" if target["units"] else ""
    print(
        f"\n  {target['quantity']}: this run {got:.4g}{unit}, paper {target['paper']:g}{unit}"
        f" (p. {target['page']}), band ±{target['band']:.3g}{unit} ({target['band_set_by']})"
    )
    assert abs(got - target["paper"]) <= target["band"], (
        f"{target['quantity']} = {got:.6g}, outside the paper's {target['paper']:g} ± {target['band']:g}"
    )
