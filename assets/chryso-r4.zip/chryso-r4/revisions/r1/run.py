"""Run this simulation without Ori:  python run.py

Reads params.json (every number, with its unit and where it came from) and
targets.json (what the paper reports, and Ori's verdict), runs compute() in
sim/model.py at the finest resolution Ori used, and prints how the result
compares with the paper. Writes results/summary.json and results/series.csv.

Edit sim/model.py or params.json and run it again. This reruns the model only;
the full verification (convergence, sensitivity, known limits) runs in Ori.
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import sim.model as model  # noqa: E402


def load(name: str) -> dict:
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def _values(group: dict | None) -> dict:
    return {k: (v["value"] if isinstance(v, dict) else v) for k, v in (group or {}).items()}


def _rngs(seed: int, count: int) -> list[np.random.Generator]:
    children = np.random.SeedSequence(seed).spawn(count)
    return [
        np.random.default_rng(np.random.SeedSequence([int(x) for x in c.generate_state(4)]))
        for c in children
    ]


def simulate(params: dict | None = None) -> dict:
    """Every output at the finest level, laid along the axis, as Ori reduced it."""
    p = params or load("params.json")
    if hasattr(model, "simulate"):
        return model.simulate(p)  # an integrated system: it knows its own time axis
    compute = model.compute
    rs = p["run_settings"]
    inputs = {**_values(p.get("inputs")), **_values(p.get("numerics")), **_values(p.get("constants"))}
    rngs = _rngs(int(rs.get("seed", 0)), int(rs.get("seeds", 1)))
    rows = [compute(dict(inputs), dict(rs.get("resolution") or {}), rng) for rng in rngs]
    stochastic = set(rs.get("stochastic_outputs") or [])
    declared = [o["name"] for o in rs.get("outputs") or []] or list(rows[0])
    values = {}
    for name in declared:
        if name in stochastic:
            values[name] = np.stack([np.asarray(r[name], dtype=float) for r in rows]).mean(axis=0)
        else:
            values[name] = np.asarray(rows[0][name], dtype=float)
    series = {k: v for k, v in values.items() if v.ndim == 1}
    axis = rs.get("axis") or {}
    axis_name, unit = axis.get("name"), axis.get("unit") or ""
    lengths = {len(v) for v in series.values()}
    axis_values = values.get(axis_name) if axis_name in values else rows[0].get(axis_name)
    if axis_values is not None and (not lengths or lengths == {len(axis_values)}):
        times = [float(x) for x in axis_values]
    elif series:
        # the model did not return its axis: the honest x is the sample number
        times, axis_name, unit = [float(i) for i in range(len(next(iter(series.values()))))], "sample", ""
    else:
        times = [0.0]
    frames = len(times) or 1
    final = {}
    for name, v in values.items():
        if v.ndim == 0:
            final[name] = [float(v)] * frames
        elif v.ndim == 1 and len(v) == frames:
            final[name] = [float(x) for x in v]
    return {
        "outputs": final,
        "times": times,
        "axis": axis_name,
        "axis_unit": unit,
        "scalars": {k: float(v) for k, v in values.items() if v.ndim == 0},
        "series_names": [k for k in series if k != axis_name],
    }


def _crossing(times, series, threshold, below):
    for i, v in enumerate(series):
        if not (v < threshold if below else v > threshold):
            continue
        if i == 0:
            return float(times[0])
        t0, t1, y0, y1 = times[i - 1], times[i], series[i - 1], series[i]
        return float(t1) if y1 == y0 else float(t0 + (threshold - y0) * (t1 - t0) / (y1 - y0))
    return None


def _at(times, series, at):
    if not times or at < times[0] or at > times[-1]:
        return None
    hits = [i for i, t in enumerate(times) if t == at]
    if hits:
        return float(series[hits[-1]])
    for i in range(1, len(times)):
        if times[i] >= at:
            t0, t1 = times[i - 1], times[i]
            if t1 == t0:
                return float(series[i])
            w = (at - t0) / (t1 - t0)
            return float(series[i - 1] + w * (series[i] - series[i - 1]))
    return float(series[0])


def measure(target: dict, result: dict) -> float | None:
    """One target's number from this run, in the target's units."""
    series = result["outputs"].get(target["output"])
    if not series or target.get("needs_ori"):
        return None
    how, times = target["statistic"], result["times"]
    if how == "mean":
        raw = sum(series) / len(series)
    elif how == "max":
        raw = max(series)
    elif how == "min":
        raw = min(series)
    elif how in ("first_below", "first_above"):
        raw = _crossing(times, series, target["threshold"], how == "first_below")
    elif how == "at":
        raw = _at(times, series, target["at"])
    else:
        raw = series[-1]
    return None if raw is None else raw * target.get("factor", 1.0)


def compare(targets: list[dict], result: dict) -> list[dict]:
    rows = []
    for t in targets:
        got = measure(t, result)
        inside = got is not None and abs(got - t["paper"]) <= t["band"]
        rows.append({**t, "this_run": got, "inside_band": inside})
    return rows


def main() -> int:
    result = simulate()
    targets = load("targets.json")
    rows = compare(targets["targets"], result)
    print()
    for r in rows:
        u = f" {r['units']}" if r["units"] else ""
        got = "no value" if r["this_run"] is None else f"{r['this_run']:.4g}{u}"
        print(f"{r['quantity']}")
        print(f"  paper     {r['paper']:g}{u}   (p. {r['page']})")
        print(f"  this run  {got}")
        print(f"  band      ±{r['band']:.3g}{u}   ({r['band_set_by']})")
        verdict = r.get("needs_ori") or ("inside the band" if r["inside_band"] else "OUTSIDE the band")
        print(f"  result    {verdict}")
        print()
    v = targets.get("verdict")
    if v:
        print(f"Ori's verdict on the full check: {v['in_words']}")
        for why in v.get("why") or []:
            print(f"  - {why}")
        print(f"  ({v['note']})")
        print()
    out = HERE / "results"
    out.mkdir(exist_ok=True)
    summary = {
        "targets": [
            {k: r.get(k) for k in ("quantity", "paper", "this_run", "units", "band", "band_set_by", "inside_band", "page")}
            for r in rows
        ],
        "scalars": result["scalars"],
        "verdict": v,
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    names = result["series_names"]
    if names:
        units = {o["name"]: o.get("unit") or "" for o in load("params.json")["run_settings"]["outputs"]}
        x = result["axis"] + (f" ({result['axis_unit']})" if result["axis_unit"] else "")
        with (out / "series.csv").open("w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow([x] + [n + (f" ({units.get(n)})" if units.get(n) else "") for n in names])
            for i, t in enumerate(result["times"]):
                w.writerow([t] + [result["outputs"][n][i] for n in names])
        print(f"wrote results/summary.json and results/series.csv ({x} against {', '.join(names)})")
    else:
        print("wrote results/summary.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
