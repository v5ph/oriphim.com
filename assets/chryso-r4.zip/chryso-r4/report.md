I modeled the radioactive decay cooldown of a gold isotope batch produced in a fusion tokamak blanket over 1 year of continuous operation, based on the transmutational inventory from Rutkowski et al. (2025, Section 4.1.2, p. 17). The batch starts with an initial inventory of five gold isotopes: $m_{195} = 289\text{ g}$, $m_{196} = 9.6\text{ g}$, $m_{197} = 2910000\text{ g}$, $m_{198} = 93.4\text{ g}$, and $m_{199} = 2.21\text{ g}$.

### Governing Equations and Observables

The unstable gold isotopes decay according to uncoupled first-order decay kinetics, while stable $^{197}\text{Au}$ maintains a constant mass:

$$\frac{dm_i}{dt} = -\frac{\ln 2}{T_{1/2,i}} m_i \quad (i \in \{195, 196, 198, 199\}), \qquad \frac{dm_{197}}{dt} = 0$$

The stated half-lives are $T_{1/2,195} = 0.51\text{ yr}$, $T_{1/2,196} = 0.0169\text{ yr}$, $T_{1/2,198} = 0.00737\text{ yr}$, and $T_{1/2,199} = 0.0086\text{ yr}$.

From the evolving isotope masses, I evaluated three activity concentration metrics over time:
- `volumetric_activity_concentration` ($\text{Ci/m}^3$), using elemental gold density $\rho_{\text{Au}} = 19.32\text{ g/cm}^3$.
- `mass_activity_concentration` ($\text{pCi/g}$).
- `troy_ounce_activity` ($\text{pCi}$ per troy ounce), using $31.1\text{ g/oz}$.

### Integration and Solution Quality

I integrated the system over a $25.0\text{ yr}$ horizon using the DOP853 solver with a relative tolerance `rtol` $= 1.00 \times 10^{-9}$ across 2001 temporal samples. All 20 typed parameters were bound, with 0 unresolved.

The run completed with `verified_core` standing, passing both numerical execution checks:
- `finite_solution`: passed, confirming every state variable remained finite across all 401 recorded frames.
- `tolerance_convergence`: passed, with a solution variation measure of $8.03 \times 10^{-15}$ against tighter reruns, remaining well below the noise floor of $1.00 \times 10^{-8}$.

### Activity Cooldown Benchmark Comparisons

In the early decay phase, short-lived isotopes ($^{196}\text{Au}$, $^{198}\text{Au}$, $^{199}\text{Au}$) undergo rapid decay within weeks, after which longer-lived $^{195}\text{Au}$ controls the activity decay curve.

All three planned threshold checks passed within the proposed $\pm 2\%$ tolerance band:
- **Class A Low-Level Waste Limit ($700\text{ Ci/m}^3$)**: The volumetric activity fell below $700\text{ Ci/m}^3$ at $t = 6.77\text{ yr}$, reproducing the target of $6.8\text{ yr}$ (passed, relative difference measure 0.00500).
- **Class 7 Exempt Limit ($2700\text{ pCi/g}$)**: The mass activity fell below $2700\text{ pCi/g}$ at $t = 13.8\text{ yr}$, reproducing the target of $13.7\text{ yr}$ (passed, relative difference measure 0.00430).
- **Banana Equivalent Handling Limit ($420\text{ pCi / troy oz}$)**: The activity per troy ounce fell below $420\text{ pCi}$ at $t = 17.5\text{ yr}$, reproducing the target of $17.7\text{ yr}$ (passed, relative difference measure 0.00868).

### Sensitivity and Scope Limitations

A post-run critique issued a warning finding regarding `param.molar_mass_197`: because $^{197}\text{Au}$ is stable and contributes zero activity to the numerator, $\partial A / \partial \text{molar\_mass\_197} = 0$ in the equations of motion, making the result invariant to changes in this specific parameter value. This was classified as a warning rather than a blocking finding.

This run establishes that our ODE decay model matches the published mathematical results of Rutkowski et al. However, numerical agreement between two computational models does not establish agreement with measured reality or physical experimental validation.
